Piont to delegate menus and to interfaces menus  from the test project for it will work as it need to.

In this solution we implemented different solutions to the familiar "reporter - listener" problem, 
in each project we solved the problem in a different way:
In one project we used INTERFACES.
Whereas in the second project we used DELEGATES and specifically ACTION (which is actually pointers to functions)