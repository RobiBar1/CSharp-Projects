﻿using System;
using System.Collections.Generic;

namespace Ex04.Menus.Delegates
{
    public class Button
    {
        private String m_Name = String.Empty;
        private String m_Text = String.Empty;
        public event Action<Button> wasClicked;

        #region Proprties
        public String Name
        {
            set
            {
                m_Name = value;
            }

            get
            {
                return m_Name;
            }
        }

        public String Text
        {
            set
            {
                m_Text = value;
            }

            get
            {
                return m_Text;
            }
        }

        #endregion Proprties
        public void Show()
        {
            OnWasClicked();
        }

        protected virtual void OnWasClicked()
        {
            wasClicked?.Invoke(this);
            /*the ? do : if its not null so the function will happned, else nothing will hapnned. its in C#.6+
             the other way to do it(without the ? mark) its:
            if(wasClicked != null)
            {
                wasClicked.Invoke(this);//wasClicked.Invoke(this); = wasClicked.(this); the first way more readable.
            } 
             */
        }
    }
}
