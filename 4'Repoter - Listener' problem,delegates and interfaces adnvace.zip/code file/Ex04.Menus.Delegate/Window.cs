﻿using System;

namespace Ex04.Menus.Delegates
{
    public class Window
    {
        private void button_WasClicked(Button i_TheButtonThatWasClicked)
        {
            //show/print some visualization that the button was clicked.
        }

        private void menu_WasClicked(Menu i_TheMenuThatWasClicked)
        {
            bool userWantOut = false;

            while (!userWantOut)
            {
                if (i_TheMenuThatWasClicked.SubMenu.Count > 0)
                {
                    Console.WriteLine("**{0}**", i_TheMenuThatWasClicked.Text);
                    int i;
                    int toPrint = 25;

                    for (i = 0; i < toPrint; i++)
                    {
                        Console.Write("-");
                    }

                    Console.WriteLine();
                    i = 1;
                    foreach (Menu menu in i_TheMenuThatWasClicked.SubMenu)
                    {
                        Console.WriteLine(String.Format("{0} -> {1}", i, menu.Text));
                        i++;
                    }
                    Console.WriteLine(String.Format("0 -> {0}", i_TheMenuThatWasClicked.
                        ButtonsInMenu[i_TheMenuThatWasClicked.ButtonsInMenu.Count - 1].Text));
                    for (i = 0; i < toPrint; i++)
                    {
                        Console.Write("-");
                    }

                    Console.WriteLine();
                    Console.WriteLine("Enter your requst: ");
                    bool validInput = false;
                    String userInput;

                    while (!validInput)
                    {
                        userInput = Console.ReadLine();
                        if (int.TryParse(userInput, out int intUserInput))
                        {
                            if (intUserInput > 0 && intUserInput <= i_TheMenuThatWasClicked.SubMenu.Count)
                            {
                                i_TheMenuThatWasClicked.SubMenu[intUserInput - 1].Show();
                                validInput = true;
                                break;
                            }
                            else if (intUserInput == 0)
                            {
                                if (i_TheMenuThatWasClicked.ButtonsInMenu[i_TheMenuThatWasClicked.ButtonsInMenu.Count - 1]
                                    .Text.Equals("Exit"))
                                {
                                    Console.WriteLine("Bye Bye :-)");
                                }

                                userWantOut = true;
                                break;
                            }
                            else
                            {
                                Console.WriteLine(string.Format("Invalid input, enter numbers in range only(0 - {0})"
                                    , i_TheMenuThatWasClicked.SubMenu.Count));
                                continue;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid input, enter numbers only, try again");
                            continue;
                        }
                    }
                }
                else if (i_TheMenuThatWasClicked.ButtonsInMenu.Count > 0)
                {
                    Console.WriteLine("**{0}**", i_TheMenuThatWasClicked.Text);
                    int i;
                    int toPrint = 25;
                    for (i = 0; i < toPrint; i++)
                    {
                        Console.Write("-");
                    }

                    Console.WriteLine();
                    i = 1;
                    foreach (Button button in i_TheMenuThatWasClicked.ButtonsInMenu)
                    {
                        if(i == i_TheMenuThatWasClicked.ButtonsInMenu.Count)
                        {
                            i = 0;
                        }
                        Console.WriteLine(String.Format("{0} -> {1}", i, button.Text));
                        i++;
                    }
                    
                    for (i = 0; i < toPrint; i++)
                    {
                        Console.Write("-");
                    }

                    Console.WriteLine();
                    Console.WriteLine("Enter your requst: ");
                    bool validInput = false;
                    String userInput;
                    while (!validInput)
                    {
                        userInput = Console.ReadLine();
                        if (int.TryParse(userInput, out int intUserInput))
                        {
                            if (intUserInput > 0 && intUserInput <= i_TheMenuThatWasClicked.ButtonsInMenu.Count - 1)
                            {
                                i_TheMenuThatWasClicked.ButtonsInMenu[intUserInput - 1].Show();
                                validInput = true;
                                break;
                            }
                            else if (intUserInput == 0)
                            {
                                if (i_TheMenuThatWasClicked.ButtonsInMenu[i_TheMenuThatWasClicked.ButtonsInMenu.Count - 1]
                                    .Text.Equals("Exit"))
                                {
                                    Console.WriteLine("Bye Bye :-)");
                                }

                                userWantOut = true;
                                break;
                            }
                            else
                            {
                                Console.WriteLine(string.Format("Invalid input, enter numbers in range only(0 - {0})"
                                    , i_TheMenuThatWasClicked.ButtonsInMenu.Count - 1));
                                continue;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid input, enter numbers only, try again");
                            continue;
                        }
                    }
                }
            }
        }

        public void LinkNewButton(Button i_NewButtonToLink)
        {
            i_NewButtonToLink.wasClicked += new Action<Button>(button_WasClicked);
            //i_NewButtonToLink.wasClicked += button_wasClicked; this lines are equal.
        }

        public void LinkNewMenu(Menu i_NewMenuToLink)
        {
            i_NewMenuToLink.MenuWasClicked += new Action<Menu>(menu_WasClicked);
        }
    }
}
