﻿using System;
using System.Collections.Generic;

namespace Ex04.Menus.Delegates
{
    public class Menu
    {
        private readonly List<Button> m_ButtonsInMenu = new List<Button>();
        private readonly List<Menu> m_SubMenu = new List<Menu>();
        public event Action<Menu> MenuWasClicked;
        private String m_Name = String.Empty;
        private String m_Text = String.Empty;

        #region Propeties
        public String Name
        {
            set
            {
                m_Name = value;
            }

            get
            {
                return m_Name;
            }
        }

        public String Text
        {
            set
            {
                m_Text = value;
            }

            get
            {
                return m_Text;
            }
        }

        public List<Button> ButtonsInMenu
        {
            get
            {
                return m_ButtonsInMenu;
            }
        }

        public List<Menu> SubMenu
        {
            get
            {
                return m_SubMenu;
            }
        }

        #endregion Propeties
        public void AddButtonToSubMenu(Button i_ToAdd)
        {
            m_ButtonsInMenu.Add(i_ToAdd);
        }

        public void RemoveButtonToSubMenu(Button i_ToRemove)
        {
            m_ButtonsInMenu.Remove(i_ToRemove);
        }

        public void AddSubMenuToMenu(Menu i_MenuToAdd)
        {
            m_SubMenu.Add(i_MenuToAdd);
        }

        public void RemoveSubMenuFromMenu(Menu i_MenuToRemove)
        {
            m_SubMenu.Remove(i_MenuToRemove);
        }

        public void Show()
        {
            On_WasClicked();
        }

        protected virtual void On_WasClicked()
        {
            MenuWasClicked?.Invoke(this);
        }
    }
}
