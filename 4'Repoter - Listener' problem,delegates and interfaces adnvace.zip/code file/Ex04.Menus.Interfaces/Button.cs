﻿using System;
using System.Collections.Generic;


namespace Ex04.Menus.Interfaces
{
    public class Button
    {
        #region Variables
        private String m_Name = String.Empty;
        private String m_Text = String.Empty;
        private readonly List<IActivator<Button>> m_Activators = new List<IActivator<Button>>();

        #endregion Variables
        #region Proprties
        public String Name
        {
            set
            {
                m_Name = value;
            }

            get
            {
                return m_Name;
            }
        }

        public String Text
        {
            set
            {
                m_Text = value;
            }

            get
            {
                return m_Text;
            }
        }

        #endregion Proprties

        public void AddActivatorToActivators(IActivator<Button> i_ToAdd)
        {
            m_Activators.Add(i_ToAdd);
        }

        public void RemoveActivatorToActivators(IActivator<Button> i_ToRemove)
        {
            m_Activators.Remove(i_ToRemove);
        }

        public void Show()
        {
            foreach (IActivator<Button> activator in m_Activators)
            {
                activator.wasClicked(this);
            }
        }
    }
}
