﻿using System;
using System.Collections.Generic;

namespace Ex04.Menus.Interfaces
{
    public class Menu : Button
    {
        private readonly List<Button> m_ButtonsInMenu = new List<Button>();
        private readonly List<Menu> m_SubMenu = new List<Menu>();

        public List<Button> ButtonsInMenu
        {
            get
            {
                return m_ButtonsInMenu;
            }
        }

        public List<Menu> SubMenu
        {
            get
            {
                return m_SubMenu;
            }
        }

        public void AddButtonToSubMenu(Button i_ToAdd)
        {
            m_ButtonsInMenu.Add(i_ToAdd);
        }

        public void RemoveButtonToSubMenu(Button i_ToRemove)
        {
            m_ButtonsInMenu.Remove(i_ToRemove);
        }

        public void AddSubMenuToMenu(Menu i_MenuToAdd)
        {
            m_SubMenu.Add(i_MenuToAdd);
        }

        public void RemoveSubMenuFromMenu(Menu i_MenuToRemove)
        {
            m_SubMenu.Remove(i_MenuToRemove);
        }
    }
}

