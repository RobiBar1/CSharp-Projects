﻿using System;
using System.Collections.Generic;

namespace Ex04.Menus.Interfaces
{
    public class Window : IActivator<Button>
    {
        private void showSubMenu(Button i_TheButtonThatWasClicked)
        {
            bool userWantOut = false;

            while (!userWantOut)
            {
                Console.WriteLine("**{0}**", i_TheButtonThatWasClicked.Text);
                int i;
                int toPrint = 25;

                for (i = 0; i < toPrint; i++)
                {
                    Console.Write("-");
                }

                Console.WriteLine();
                i = 1;
                foreach (Menu menu in (i_TheButtonThatWasClicked as Menu).SubMenu)
                {
                    Console.WriteLine(String.Format("{0} -> {1}", i, menu.Text));
                    i++;
                }

                Console.WriteLine(String.Format("0 -> {0}", (i_TheButtonThatWasClicked as Menu).
                   ButtonsInMenu[(i_TheButtonThatWasClicked as Menu).ButtonsInMenu.Count - 1].Text));
                for (i = 0; i < toPrint; i++)
                {
                    Console.Write("-");
                }

                Console.WriteLine();
                Console.WriteLine("Enter your requst: ");
                bool validInput = false;
                String userInput;

                while (!validInput)
                {
                    userInput = Console.ReadLine();
                    if (int.TryParse(userInput, out int intUserInput))
                    {
                        if (intUserInput > 0 && intUserInput <= (i_TheButtonThatWasClicked as Menu).SubMenu.Count)
                        {
                            (i_TheButtonThatWasClicked as Menu).SubMenu[intUserInput - 1].Show();
                            validInput = true;
                            break;
                        }
                        else if (intUserInput == 0)
                        {
                            if ((i_TheButtonThatWasClicked as Menu).ButtonsInMenu
                                [(i_TheButtonThatWasClicked as Menu).ButtonsInMenu.Count - 1].Text.Equals("Exit"))
                            {
                                Console.WriteLine("Bye Bye :-)");
                            }

                            userWantOut = true;
                            break;
                        }
                        else
                        {
                            Console.WriteLine(string.Format("Invalid input, enter numbers in range only(0 - {0})"
                                , (i_TheButtonThatWasClicked as Menu).SubMenu.Count));
                            continue;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input, enter numbers only, try again");
                        continue;
                    }
                }
            } 
        }

        private void showButtonsOnSubMenu(Button i_TheButtonThatWasClicked)
        {
            bool userWantOut = false;

            while(!userWantOut)
            {
                Console.WriteLine("**{0}**", i_TheButtonThatWasClicked.Text);
                int i;
                int toPrint = 25;

                for (i = 0; i < toPrint; i++)
                {
                    Console.Write("-");
                }

                Console.WriteLine();
                i = 1;
                foreach (Button button in (i_TheButtonThatWasClicked as Menu).ButtonsInMenu)
                {
                    if (i == (i_TheButtonThatWasClicked as Menu).ButtonsInMenu.Count)
                    {
                        i = 0;
                    }

                    Console.WriteLine(String.Format("{0} -> {1}", i, button.Text));
                    i++;
                }

                for (i = 0; i < toPrint; i++)
                {
                    Console.Write("-");
                }

                Console.WriteLine();
                Console.WriteLine("Enter your requst: ");
                bool validInput = false;
                String userInput;

                while (!validInput)
                {
                    userInput = Console.ReadLine();
                    if (int.TryParse(userInput, out int intUserInput))
                    {
                        if (intUserInput > 0 && intUserInput <= (i_TheButtonThatWasClicked as Menu).ButtonsInMenu.Count - 1)
                        {
                            (i_TheButtonThatWasClicked as Menu).ButtonsInMenu[intUserInput - 1].Show();
                            validInput = true;
                            break;
                        }
                        else if (intUserInput == 0)
                        {
                            if ((i_TheButtonThatWasClicked as Menu).ButtonsInMenu
                                [(i_TheButtonThatWasClicked as Menu).ButtonsInMenu.Count - 1].Text.Equals("Exit"))
                            {
                                Console.WriteLine("Bye Bye :-)");
                            }

                            userWantOut = true;
                            break;
                        }
                        else
                        {
                            Console.WriteLine(string.Format("Invalid input, enter numbers in range only(0 - {0})"
                                , (i_TheButtonThatWasClicked as Menu).ButtonsInMenu.Count - 1));
                            continue;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input, enter numbers only, try again");
                        continue;
                    }
                }
            }
        }

        void IActivator<Button>.wasClicked(Button i_TheButtonThatWasClicked)
        {
            if (i_TheButtonThatWasClicked is Menu && (i_TheButtonThatWasClicked as Menu).SubMenu.Count > 0)
            {
                showSubMenu(i_TheButtonThatWasClicked);
            }
            else if(i_TheButtonThatWasClicked is Menu && (i_TheButtonThatWasClicked as Menu).ButtonsInMenu.Count > 0)
            {
                showButtonsOnSubMenu(i_TheButtonThatWasClicked);
            }
        }
    }
}
