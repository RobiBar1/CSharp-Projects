﻿using System;
using System.Collections.Generic;

namespace Ex04.Menus.Interfaces
{
    public interface IActivator<T>
    {
        void wasClicked(T i_WasClicked);
    }
}
