﻿using System;
using Ex04.Menus;
using Ex04.Menus.Delegates;
using Ex04.Menus.Interfaces;

namespace Ex04.Menus.Test
{
    public class Program
    {
        static MainMenu m_MainMenu = new MainMenu();
        public static void Main()
        {
            ProjectTests();    
        }

        public static void ProjectTests()
        {
            Menus.Delegates.Window mainWindow = new Menus.Delegates.Window();
            #region Menus
            Menus.Delegates.Menu VersionAndUppercaseMenu = m_MainMenu.InitNewMenuToDelegateProject("VersionAndUppercaseMenu",
                "Version and Uppercase", mainWindow);
            Menus.Delegates.Menu ShowDateTimeMenu = m_MainMenu.InitNewMenuToDelegateProject("ShowDateTimeMenu",
                "Show Date/Time", mainWindow);
            Menus.Delegates.Menu MainMenu = m_MainMenu.InitNewMenuToDelegateProject("MainMenu", "Delegates Main Menu"
                , mainWindow);
            #endregion Menus
            #region Buttons
            Menus.Delegates.Button ExitButton = initNewButtonToDelegateProject("ExitButton", "Exit", mainWindow);
            Menus.Delegates.Button BackButton = initNewButtonToDelegateProject("BackButton", "Back", mainWindow);
            Menus.Delegates.Button ShowVersionButton = initNewButtonToDelegateProject("ShowVersionButton",
                "Show Version", mainWindow);
            Menus.Delegates.Button CountUppercaseButton = initNewButtonToDelegateProject("CountUppercaseButton",
                "Count Uppercase", mainWindow);
            Menus.Delegates.Button ShowDateButton = initNewButtonToDelegateProject("ShowDateButton",
                "Show Date", mainWindow);
            Menus.Delegates.Button ShowTimeButton = initNewButtonToDelegateProject("ShowTimeButton",
                "Show Time", mainWindow);

            #endregion Buttons
            #region menus load with subMenus/Buttons
            m_MainMenu.AddSubMenuToMenuToDelegateProject(MainMenu, VersionAndUppercaseMenu);
            m_MainMenu.AddSubMenuToMenuToDelegateProject(MainMenu, ShowDateTimeMenu);
            addButtonToSubMenuToDelegateProject(MainMenu, ExitButton);
            addButtonToSubMenuToDelegateProject(VersionAndUppercaseMenu, ShowVersionButton);
            addButtonToSubMenuToDelegateProject(VersionAndUppercaseMenu, CountUppercaseButton);
            addButtonToSubMenuToDelegateProject(VersionAndUppercaseMenu, BackButton);
            addButtonToSubMenuToDelegateProject(ShowDateTimeMenu, ShowDateButton);
            addButtonToSubMenuToDelegateProject(ShowDateTimeMenu, ShowTimeButton);
            addButtonToSubMenuToDelegateProject(ShowDateTimeMenu, BackButton);
            #endregion menus load with subMenus/Buttons
            InterfaceProjectTest();
            m_MainMenu.Show();
        }

        #region delegate menu for main
        private static Menus.Delegates.Button initNewButtonToDelegateProject(String i_Name, String i_Text
            , Menus.Delegates.Window i_window)
        {
            Menus.Delegates.Button o_NewButton = new Menus.Delegates.Button();

            o_NewButton.Name = i_Name;
            o_NewButton.Text = i_Text;
            i_window.LinkNewButton(o_NewButton);
            o_NewButton.wasClicked += m_MainMenu.Button_WasClickedDelegates;

            return o_NewButton;
        }

        private static void addButtonToSubMenuToDelegateProject(Menus.Delegates.Menu i_TheMenu
           , Menus.Delegates.Button i_TheButtonIWantToAddToMenu)
        {
            i_TheMenu.AddButtonToSubMenu(i_TheButtonIWantToAddToMenu);
        }

        #endregion delegate menu for main
        #region interfaces menu for main
        public static void InterfaceProjectTest()
        {
            Interfaces.Window MainWindow = new Interfaces.Window();
            #region menus
            Interfaces.Menu MainMenu = m_MainMenu.InitNewMenuAndLinkToWindowInterfacesProject("MainMenu", "Interfaces Main Menu"
                , MainWindow);
            Interfaces.Menu VersionAndUppercaseMenu = m_MainMenu.InitNewMenuAndLinkToWindowInterfacesProject("VersionAndUppercaseMenu",
                "Version and Uppercase", MainWindow);
            Interfaces.Menu ShowDateTimeMenu = m_MainMenu.InitNewMenuAndLinkToWindowInterfacesProject("ShowDateTimeMenu",
                "Show Date/Time", MainWindow);
            #endregion menus
            #region Buttons 
            Interfaces.Button ExitButton = initNewButtonToInterfacesProject("ExitButton", "Exit", MainWindow);
            Interfaces.Button BackButton = initNewButtonToInterfacesProject("BackButton", "Back", MainWindow);
            Interfaces.Button ShowVersionButton = initNewButtonToInterfacesProject("ShowVersionButton",
                "Show Version", MainWindow);
            Interfaces.Button CountUppercaseButton = initNewButtonToInterfacesProject("CountUppercaseButton",
                "Count Uppercase", MainWindow);
            Interfaces.Button ShowDateButton = initNewButtonToInterfacesProject("ShowDateButton",
                "Show Date", MainWindow);
            Interfaces.Button ShowTimeButton = initNewButtonToInterfacesProject("ShowTimeButton",
                "Show Time", MainWindow);
            #endregion Buttons

            #region menus load with subMenus/Buttons
            m_MainMenu.AddSubMenuToMenuToInterfacesProject(MainMenu, VersionAndUppercaseMenu);
            m_MainMenu.AddSubMenuToMenuToInterfacesProject(MainMenu, ShowDateTimeMenu);
            addButtonToSubMenuToInterfacesProject(MainMenu, ExitButton);
            addButtonToSubMenuToInterfacesProject(VersionAndUppercaseMenu, ShowVersionButton);
            addButtonToSubMenuToInterfacesProject(VersionAndUppercaseMenu, CountUppercaseButton);
            addButtonToSubMenuToInterfacesProject(VersionAndUppercaseMenu, BackButton);
            addButtonToSubMenuToInterfacesProject(ShowDateTimeMenu, ShowDateButton);
            addButtonToSubMenuToInterfacesProject(ShowDateTimeMenu, ShowTimeButton);
            addButtonToSubMenuToInterfacesProject(ShowDateTimeMenu, BackButton);
            #endregion menus load with subMenus/Buttons
        }

        private static Interfaces.Button initNewButtonToInterfacesProject(String i_Name, String i_Text
            , Interfaces.Window i_window)
        {
            Interfaces.Button o_NewButton = new Interfaces.Button();

            o_NewButton.Name = i_Name;
            o_NewButton.Text = i_Text;
            o_NewButton.AddActivatorToActivators(i_window);
            o_NewButton.AddActivatorToActivators(m_MainMenu);

            return o_NewButton;
        }

        private static void addButtonToSubMenuToInterfacesProject(Interfaces.Menu i_TheMenu
            , Interfaces.Button i_TheButtonIWantToAddToMenu)
        {
            i_TheMenu.AddButtonToSubMenu(i_TheButtonIWantToAddToMenu);
        }

        #endregion interfaces menu for main
    }
}

