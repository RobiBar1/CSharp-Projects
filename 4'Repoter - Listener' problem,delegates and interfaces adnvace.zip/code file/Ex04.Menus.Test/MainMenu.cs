﻿using System;
using System.Collections.Generic;
using Ex04.Menus.Interfaces;

namespace Ex04.Menus.Test
{
    public class MainMenu : IActivator<Interfaces.Button>
    {
        private readonly List<Delegates.Menu> m_DelegatesMenusList = new List<Delegates.Menu>(2);
        private readonly List<Interfaces.Menu> m_InterfacesMenusList = new List<Interfaces.Menu>(2);
        
        private void addMainMenuToDelegatesList(Delegates.Menu i_MenuToAdd)
        {
            if(m_DelegatesMenusList.Count == 0)
            {
                m_DelegatesMenusList.Add(i_MenuToAdd);
            }
        }

        private void addMainMenuToInterfacesList(Interfaces.Menu i_MenuToAdd)
        {
            if (m_InterfacesMenusList.Count == 0)
            {
                m_InterfacesMenusList.Add(i_MenuToAdd);
            }
        }

        #region Interface functions
        public void AddSubMenuToMenuToInterfacesProject(Interfaces.Menu i_TheMenu
           , Interfaces.Menu i_TheSubMenuIWantToAddToMenu)
        {
            i_TheMenu.AddSubMenuToMenu(i_TheSubMenuIWantToAddToMenu);
        }

        public Interfaces.Menu InitNewMenuAndLinkToWindowInterfacesProject(String i_Name, String i_Text
            , Interfaces.Window i_window)
        {
            Interfaces.Menu o_NewMenu = new Interfaces.Menu();

            o_NewMenu.Name = i_Name;
            o_NewMenu.Text = i_Text;
            o_NewMenu.AddActivatorToActivators(i_window);
            if (i_Name.Equals("MainMenu"))
            {
                addMainMenuToInterfacesList(o_NewMenu);
            }

            return o_NewMenu;
        }

        #endregion Interface function's
        #region Delegates functions
        public Menus.Delegates.Menu InitNewMenuToDelegateProject(String i_Name, String i_Text
            , Menus.Delegates.Window i_window)
        {
            Menus.Delegates.Menu o_NewMenu = new Menus.Delegates.Menu();

            o_NewMenu.Name = i_Name;
            o_NewMenu.Text = i_Text;
            i_window.LinkNewMenu(o_NewMenu);
            if (i_Name.Equals("MainMenu"))
            {
                addMainMenuToDelegatesList(o_NewMenu);
            }

            return o_NewMenu;
        }

        public void AddSubMenuToMenuToDelegateProject(Menus.Delegates.Menu i_TheMenu
            , Menus.Delegates.Menu i_TheSubMenuIWantToAddToMenu)
        {
            i_TheMenu.AddSubMenuToMenu(i_TheSubMenuIWantToAddToMenu);
        }

        public void wasClicked(Interfaces.Button i_WasClicked)
        {
            bool userWantOut = false;

            while (!userWantOut)
            {
                String nameOfFucntionToActive = i_WasClicked.Name;

                if (Enum.IsDefined(typeof(FunctionsOfButtonsWeSupport), nameOfFucntionToActive))
                {
                    foreach (FunctionsOfButtonsWeSupport function in (FunctionsOfButtonsWeSupport[])
                                            Enum.GetValues(typeof(FunctionsOfButtonsWeSupport)))
                    {
                        if (nameOfFucntionToActive.Equals(function.ToString()))
                        {
                            switch (function)
                            {
                                case FunctionsOfButtonsWeSupport.ShowDateButton:
                                    ShowDate();
                                    userWantOut = true;
                                    break;
                                case FunctionsOfButtonsWeSupport.ShowTimeButton:
                                    ShowTime();
                                    userWantOut = true;
                                    break;
                                case FunctionsOfButtonsWeSupport.CountUppercaseButton:
                                    CountUppercase();
                                    userWantOut = true;
                                    break;
                                case FunctionsOfButtonsWeSupport.ShowVersionButton:
                                    ShowVersion();
                                    userWantOut = true;
                                    break;
                            }

                            break;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("We dont support that button");
                    break;
                }
            }
        }

        internal void Button_WasClickedDelegates(Delegates.Button i_TheButtonThatWasClicked)
        {
            bool userWantOut = false;

            while (!userWantOut)
            {
                String nameOfFucntionToActive = i_TheButtonThatWasClicked.Name;

                if (Enum.IsDefined(typeof(FunctionsOfButtonsWeSupport), nameOfFucntionToActive))
                {
                    foreach (FunctionsOfButtonsWeSupport function in (FunctionsOfButtonsWeSupport[])
                                            Enum.GetValues(typeof(FunctionsOfButtonsWeSupport)))
                    {
                        if (nameOfFucntionToActive.Equals(function.ToString()))
                        {
                            switch (function)
                            {
                                case FunctionsOfButtonsWeSupport.ShowDateButton:
                                    ShowDate();
                                    userWantOut = true;
                                    break;
                                case FunctionsOfButtonsWeSupport.ShowTimeButton:
                                    ShowTime();
                                    userWantOut = true;
                                    break;
                                case FunctionsOfButtonsWeSupport.CountUppercaseButton:
                                    CountUppercase();
                                    userWantOut = true;
                                    break;
                                case FunctionsOfButtonsWeSupport.ShowVersionButton:
                                    ShowVersion();
                                    userWantOut = true;
                                    break;
                            }

                            break;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("We dont support that button");
                    break;
                }
            }
        }

        #endregion Delegates functions
        #region Buttons functions
        public void ShowVersion()
        {
            Console.WriteLine("Version: 23.1.4.8859");
        }

        public void ShowDate()
        {
            Console.WriteLine("The current date is: {0}/{1}/{2}", DateTime.Now.Day, DateTime.Now.Month, DateTime.Now.Year);
        }

        public void ShowTime()
        {
            if ((int.TryParse(DateTime.Now.Hour.ToString(), out int hourInts)) && hourInts < 10)
            {
                Console.Write("The time is: 0{0}:", DateTime.Now.Hour);
            }
            else
            {
                Console.Write("The time is: {0}:", DateTime.Now.Hour);
            }

            if ((int.TryParse(DateTime.Now.Minute.ToString(), out int minInts)) && minInts < 10)
            {
                Console.Write("0{0}:", DateTime.Now.Minute);
            }
            else
            {
                Console.Write("{0}:", DateTime.Now.Minute);
            }

            if ((int.TryParse(DateTime.Now.Second.ToString(), out int secInts)) && secInts < 10)
            {
                Console.Write("0{0}", DateTime.Now.Second);
            }
            else
            {
                Console.Write("{0}", DateTime.Now.Second);
            }

            Console.WriteLine();
        }

        public void CountUppercase()
        {
            bool isValid = false;
            string englishWord;
            int countingCapitalLetters = 0;
            char[] charEnglishWord = null;

            Console.WriteLine("Please enter an english word: ");
            while (!isValid)
            {
                englishWord = Console.ReadLine();
                charEnglishWord = englishWord.ToCharArray();
                foreach (char value in charEnglishWord)
                {
                    if (!char.IsLetter(value))
                    {
                        isValid = false;
                        Console.WriteLine("The word is incorrect, please try again");
                        break;
                    }
                    else
                    {
                        isValid = true;
                    }
                }
            }

            foreach (char value in charEnglishWord)
            {
                if (char.IsUpper(value))
                {
                    countingCapitalLetters++;
                }
            }

            Console.WriteLine("The number of capital letters is: {0}", countingCapitalLetters);
        }

        #endregion Buttons functions
        public void Show()
        {
            m_DelegatesMenusList[0]?.Show();
            Console.Clear();
            m_InterfacesMenusList[0]?.Show();
            Console.WriteLine("Press enter to exit..");
            Console.ReadLine();
        }
    }

    enum FunctionsOfButtonsWeSupport
    {
        ShowVersionButton = 1,
        CountUppercaseButton,
        ShowDateButton,
        ShowTimeButton
    }
}
