﻿using System;

namespace Ex01_01
{
    public class Program
    {
        static void Main()
        {
            s_MethodManager01();
        }

        static public void s_MethodManager01()
        {
            int zeroCounter = 0, oneCounter = 0, counterOfNumberdivedeWith4 = 0;

            string strNumber1 = s_GetEightDigitInBinarFormat();
            string strNumber2 = s_GetEightDigitInBinarFormat();
            string strNumber3 = s_GetEightDigitInBinarFormat();

            int intNum = s_ConvertBinarStringToDecimalString(strNumber1);
            int intNum1 = s_ConvertBinarStringToDecimalString(strNumber2);
            int intNum2= s_ConvertBinarStringToDecimalString(strNumber3);

            if (s_isNumberDivideBy4(intNum)) { counterOfNumberdivedeWith4++; }

            if (s_isNumberDivideBy4(intNum1)) { counterOfNumberdivedeWith4++; }

            if (s_isNumberDivideBy4(intNum2)) { counterOfNumberdivedeWith4++; }

            int numOfOrderNumbersFromLeftToRight = 0;

            if (s_IsNumberReallyGoingDown(intNum.ToString())) { numOfOrderNumbersFromLeftToRight++; };

            if (s_IsNumberReallyGoingDown(intNum1.ToString())) { numOfOrderNumbersFromLeftToRight++; };

            if (s_IsNumberReallyGoingDown(intNum2.ToString())) { numOfOrderNumbersFromLeftToRight++; };

            string strNumberInDecimal = intNum.ToString();
            string strNumberInDecimal1 = intNum1.ToString();
            string strNumberInDecimal2 = intNum2.ToString();

            int numOfPolindromNumbers = s_IsStringPolindromRecursia(strNumberInDecimal, 0, strNumberInDecimal.Length - 1);

            numOfPolindromNumbers += s_IsStringPolindromRecursia(strNumberInDecimal1, 0, strNumberInDecimal1.Length - 1);
            numOfPolindromNumbers += s_IsStringPolindromRecursia(strNumberInDecimal2, 0, strNumberInDecimal2.Length - 1);

            int sumZeroLetters = s_LetterZeroCounter(strNumber1);
            int sumZeroLetters1 = s_LetterZeroCounter(strNumber2);
            int sumZeroLetters2 = s_LetterZeroCounter(strNumber3);

            int sumOneLetters = s_LetterOneCounter(strNumber1);
            int sumOneLetters1 = s_LetterOneCounter(strNumber2);
            int sumOneLetters2 = s_LetterOneCounter(strNumber3);

            Console.WriteLine(string.Format("number 1 in binar is: {0} and in decimal is: {1} its have {2} zeros, and {3} ones", strNumber1, intNum, sumZeroLetters, sumOneLetters));
            Console.WriteLine(string.Format("number 2 in binar is: {0} and in decimal is: {1} its have {2} zeros, and {3} ones", strNumber2, intNum1, sumZeroLetters1, sumOneLetters1));
            Console.WriteLine(string.Format("number 3 in binar is: {0} and in decimal is: {1} its have {2} zeros, and {3} ones", strNumber3, intNum2, sumZeroLetters2, sumOneLetters2));
            zeroCounter = sumZeroLetters + sumZeroLetters1 + sumZeroLetters2;
            oneCounter = sumOneLetters + sumOneLetters1 + sumOneLetters2;
            float avrageOne = (float)oneCounter / 3;
            float avrageZero = (float)zeroCounter / 3;

            Console.WriteLine("Statistic information: -------------------------------------------------");
            Console.WriteLine(string.Format("the average of 1 number is: {0} and the average of 0 number is: {1} ", avrageOne, avrageZero));
            Console.WriteLine(string.Format("The number of numbers that divede with 4 is: {0} ", counterOfNumberdivedeWith4));
            Console.WriteLine(string.Format("The number of series is really going down is: {0} ", numOfOrderNumbersFromLeftToRight));
            Console.WriteLine(string.Format("The number of polindrom numbers is: {0} ", numOfPolindromNumbers));
            Console.WriteLine("End of statistic information: -------------------------------------------------");
            Console.WriteLine("Please press 'Enter' to exit...");
            Console.ReadLine();
        }

        public static bool s_isNumberDivideBy4(int i_NumberWeCheack)
        {
            return i_NumberWeCheack % 4 == 0;
        }
        static public string s_GetEightDigitInBinarFormat()
        {
            string strBinarDigit = "-1";
            bool inValidInputLength = true, inValidInputDigits = true;

            while (inValidInputDigits || inValidInputLength)
            {
                Console.WriteLine("Please enter number with 8 digit in binary form(only 0-1 include)");
                strBinarDigit = Console.ReadLine();
                if (strBinarDigit.Length != 8)
                {
                    Console.WriteLine("the number must be in 8 digits build with 0/1 numbers only, try again");
                    inValidInputLength = true;
                    continue;
                }

                inValidInputLength = !true;
                for (int index = 0; index < strBinarDigit.Length; index++)
                {
                    if (strBinarDigit[index] != '0' && strBinarDigit[index] != '1')
                    {
                        Console.WriteLine("the number must be build with 0/1 numbers only, try again");
                        inValidInputLength = true;
                        inValidInputDigits = true;
                        break;
                    }
                }

                if (inValidInputLength)
                {
                    continue;
                }

                inValidInputDigits = !true;
            }
            
            return strBinarDigit;
        }
        static public int s_ConvertBinarStringToDecimalString(string i_BinarNumber)
        {
            int decimalNumber = 0;

            for (int indexInString = i_BinarNumber.Length - 1, numToPow = 0; indexInString >= 0; indexInString--, numToPow++)
            {
                if (i_BinarNumber[indexInString] == '1')
                {
                    decimalNumber += (int)Math.Pow(2, numToPow);
                }
            }

            return decimalNumber; 
        }
        static public int s_LetterZeroCounter(string i_StrNumber)
        {
            int counter = 0;

            for (int index = 0; index < i_StrNumber.Length; index++)
            {
                if (i_StrNumber[index] == '0')
                {
                    counter++;
                }
            }

            return counter;
        }

        static public int s_LetterOneCounter(string i_StrNumber)
        {
            int counter = 0;

            for (int index = 0; index < i_StrNumber.Length; index++)
            {
                if (i_StrNumber[index] == '1')
                {
                    counter++;
                }
            }

            return counter;
        }

        static public bool s_IsNumberReallyGoingDown(string i_StrNumber)
        {
            bool flag = true;

            for (int index = 0; index < i_StrNumber.Length-1; index++)
            {
                if (i_StrNumber[index] >= i_StrNumber[index + 1])
                {
                    flag = !flag;
                }
            }

            return flag;
        }

        static public int s_IsStringPolindromRecursia(string i_Str, int i_StartIndex, int i_EndIndex)
        {
            if (i_Str.Length < 0)
            {
                return 0;
            }

            if (i_Str.Length <= 1 || i_EndIndex - i_StartIndex <= 0)
            {
                return 1;
            }

            if(i_Str[i_StartIndex] == i_Str[i_EndIndex])
            {
                return s_IsStringPolindromRecursia(i_Str, i_StartIndex+1, i_EndIndex-1);
            }

            return 0;
        }
    }
}
