﻿using System;
using System.Text;

namespace Ex01_04
{
    class Program
    {
        static void Main()
        {
            s_MethodManager04();
        }
        static public void s_MethodManager04()
        {
            string myLetter = s_GetSixCharacterString();
            int myPolindrom = s_IsStringPolindromRecursia(myLetter, 0, myLetter.Length - 1);

            if (myPolindrom == 1)
            {
                Console.WriteLine("There is a polindrom!");
            }

            else if (myPolindrom == 0)
            {
                Console.WriteLine("There is not a polindrom!");
            }

            s_IsNumberDevideByThree(myLetter);
            s_AmountOfCapitalLetters(myLetter);
            Console.WriteLine("Please press 'Enter' to exit:");
            Console.ReadLine();
        }
        static public int s_IsStringPolindromRecursia(string i_Str, int i_StartIndex, int i_EndIndex)
        {
            if (i_Str.Length < 0)
            {

                return 0;
            }

            if (i_Str.Length <= 1 || i_EndIndex - i_StartIndex <= 0)
            {

                return 1;
            }

            if (i_Str[i_StartIndex] == i_Str[i_EndIndex])
            {

                return s_IsStringPolindromRecursia(i_Str, i_StartIndex + 1, i_EndIndex - 1);
            }

            return 0;
        }
        static public void s_IsNumberDevideByThree(string i_letterDivision)
        {
            foreach (char letter in i_letterDivision)
            {
                if (Char.IsNumber(letter))
                {
                    continue;
                }

                else
                {
                    Console.WriteLine("The input is not a number so its not divide by 3.");

                    return;
                }
            }

            int numberDivision = 0;

            int.TryParse(i_letterDivision, out numberDivision);
            if (numberDivision % 3 == 0)
            {
                Console.WriteLine("The number is divide by 3!");
            }

            else
            {
                Console.WriteLine("The number is not divide by 3!");
            }
        }
        static public string s_GetSixCharacterString()
        {
            string sixCharacters;
            bool isValidInput = !true, isValidLength = !true;
            StringBuilder o_Result = new StringBuilder();

            Console.WriteLine("Please enter promt with 6 digits, use: only numbers or only letter's:");
            sixCharacters = Console.ReadLine();
            while (!isValidInput || !isValidLength)
            {   
                if(sixCharacters.Length != 6) 
                {
                    o_Result.Clear();
                    Console.WriteLine("The input is invalid length, please enter 6 letter's or 6 digiti's only: ");
                    sixCharacters = Console.ReadLine();
                    isValidLength = !true;
                    continue;
                }

                isValidLength = true;
                foreach (char letter in sixCharacters)
                {
                    if (sixCharacters[0] >= 'A' && sixCharacters[0] <= 'Z' || sixCharacters[0] >= 'a' && sixCharacters[0] <= 'z')
                    {
                        if (Char.IsLetter(letter))
                        {
                            o_Result.Append(letter);
                        }

                        else if (!Char.IsLetter(letter))
                        {
                            o_Result.Clear();
                            isValidLength = !true;
                            isValidInput = !true;
                            break;
                        }
                    }

                    else if (Char.IsNumber(letter))
                    {
                        o_Result.Append(letter);
                    }

                    else
                    {
                        o_Result.Clear();
                        isValidLength = !true;
                        isValidInput = !true;
                        break;
                    }
                }

                if(o_Result.Length == sixCharacters.Length)
                {
                    isValidInput = true;
                    isValidLength = true;
                }
                else
                {
                    Console.WriteLine("The letter does not meet the condition, please try enter: 6 digit's only or 6 letter's only:");
                    sixCharacters = Console.ReadLine();
                }
            }

            return o_Result.ToString();
        }
        static public void s_AmountOfCapitalLetters(string i_CapitalLetters)
        {
            int o_Count = 0;

            if (Char.IsNumber(i_CapitalLetters[0]))
            {
                Console.WriteLine("The output is a number, so we have 0 capital letters!");
            }
            else
            {
                foreach (char letter in i_CapitalLetters)
                {
                    if (Char.IsUpper(letter))
                    {
                        o_Count++;
                    }
                }

                Console.WriteLine("The word have {0} capital letters!", o_Count);
            }
        }
    }
}
