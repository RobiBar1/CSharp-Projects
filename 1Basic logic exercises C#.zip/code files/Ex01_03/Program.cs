﻿using System;

namespace Ex01_03
{
    class Program
    {
        static void Main()
        {
            s_MethodManager03();
        }
        public static void s_MethodManager03()
        {
            s_BuildDimondHightWithInput();
            Console.WriteLine("Please press 'Enter' to exit...");
            Console.ReadLine();
        }

        public static void s_BuildDimondHightWithInput()
        {
            int hight = 0;
            bool isValidInput = !true;
            string strNumber = "";

            Console.WriteLine("Enter hight of dimond you want to build(complete numbers only)");
            while (!isValidInput)
            {
                strNumber = Console.ReadLine();
                isValidInput = true;
                foreach (char item in strNumber)
                {
                    if (item < '0' || item > '9')
                    {
                        Console.WriteLine("Wrong input, please try again");
                        isValidInput = !true;
                        break;
                    }
                }
            }

            int.TryParse(strNumber, out hight);
            Ex01_02.Program.s_BuildDimondHight(hight, 0);
        }
    }
}
