﻿using System;

namespace Ex01_05
{
    class Program
    {
        static void Main()
        {
            s_MethodManager05();
        }
        public static void s_MethodManager05()
        {
            string cheack = s_GetSixNumbersInput();

            s_FindBiggerDigitsThenUnityDigit(cheack);
            s_FindMinDigitInNumber(cheack);
            s_CheackIfDigitDivideBy3(cheack);
            s_FindAverageNumberFromDigits(cheack);
            Console.WriteLine("Please press 'Enter' to exit...");
            Console.ReadLine();
        }
        public static string s_GetSixNumbersInput()
        {
            string o_StrNumber = "-1";
            bool inValidInputLength = !true, inValidInputDigits = !true;

            Console.WriteLine("Please enter number with 6 digit's");
            while (!inValidInputDigits || !inValidInputLength)
            {
                o_StrNumber = Console.ReadLine();
                if (o_StrNumber.Length != 6)
                {
                    Console.WriteLine("Invalid input Length, try again");
                    inValidInputLength = !true;
                    continue;
                }

                inValidInputLength = true;
                inValidInputDigits = true;
                foreach (Char letter in o_StrNumber)
                {
                    if( !true == Char.IsDigit(letter))
                    {
                        Console.WriteLine("Invalid input, try again(enter number's only)");
                        inValidInputDigits = !true;
                        break;
                    }
                }
            }

            return o_StrNumber;
        }
        public static void s_FindBiggerDigitsThenUnityDigit(string i_StrNumber)
        {
            char unityDigit = i_StrNumber[i_StrNumber.Length - 1];
            int numbersBiggerThenUnityCounter = 0;

            foreach (char number in i_StrNumber)
            {
                if(number > unityDigit)
                {
                    numbersBiggerThenUnityCounter++;
                }
            }

            Console.WriteLine(String.Format("The number of digit's greater than the unity number is: {0} ", numbersBiggerThenUnityCounter));
        }
        public static void s_FindMinDigitInNumber(string i_StrNumber)
        {
            char min = '9';

            foreach (char letter in i_StrNumber)
            {
                if(letter < min)
                {
                    min = letter;
                }
            }

            Console.WriteLine(String.Format("The minimum(value) digit is the number: {0} ", min));
        }
        public static void s_CheackIfDigitDivideBy3(string i_StrNumber)
        {
            int numberDivideBy3Counter = 0;

            foreach (char letter in i_StrNumber)
            {
                if ((letter-48) % 3 == 0)
                {
                    numberDivideBy3Counter++;
                }
            }

            Console.WriteLine(String.Format("The number of digit's that divide by 3 wihtout rest is: {0} ",numberDivideBy3Counter));
        }
        public static void s_FindAverageNumberFromDigits(string i_StrNumber)
        {
            int sumAllDitigts = 0;
            float avargeAllDigits = 0;

            foreach (char number in i_StrNumber)
            {
                sumAllDitigts += number - 48;
            }

            avargeAllDigits = (float)sumAllDitigts / 6;
            Console.WriteLine(String.Format("The digit's avarge is: {0} ",avargeAllDigits));
        }
    }  
}
