﻿using System;

namespace Ex01_02
{
    public class Program
    {
        static void Main()
        {
            s_MethodManager02();
        }
        public static void s_MethodManager02()
        {
            s_BuildDimondHight(9,0);
            Console.WriteLine("Please press 'Enter' to exit...");
            Console.ReadLine();
        }

        public static void s_BuildDimondHight(int i_MaxHight, int i_CurrectHight)
        { 
            if(i_MaxHight % 2 == 0)
            {
                i_MaxHight++;
            }

            if (i_CurrectHight > i_MaxHight / 2)
            {

                return;
            }

            int spaceNeed = i_MaxHight / 2 - i_CurrectHight;

            for (int spaceCounter = 0; spaceCounter < spaceNeed; spaceCounter++)
            {
                Console.Write(" ");
            }

            for (int dasteriskCounter = 0; dasteriskCounter <i_CurrectHight*2+1 ; dasteriskCounter++)
            {
                Console.Write("*");
            }

            Console.WriteLine();
            s_BuildDimondHight(i_MaxHight,i_CurrectHight+1);
            if (i_CurrectHight == i_MaxHight / 2)
            {

                return;
            }

            for (int spaceCounter = 0; spaceCounter < spaceNeed; spaceCounter++)
            {
                Console.Write(" ");
            }

            for (int dasteriskCounter = 0; dasteriskCounter < i_CurrectHight * 2 + 1; dasteriskCounter++)
            {
                Console.Write("*");
            }

            Console.WriteLine();

            return;
        }
    }
}
