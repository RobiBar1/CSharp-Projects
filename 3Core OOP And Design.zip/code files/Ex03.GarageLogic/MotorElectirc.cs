﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex03.GarageLogic
{
    public class MotorElectirc : Vehicle, IElectric, IMotor
    {
        //IMotor varibles:
        private String m_LicenseType;
        private int m_EngineCapacityInCc;
        //IElectric varibles:
        private float m_ChargeTimeRemindInHours;
        private float m_MaxChargeTimePosibleInHours;

        //Method's--------------------------------------:
        //MotorElectirc method's:
        public MotorElectirc()
        {
            CreateWeels();
            MaxChargeTimePosibleInHours = 1.6f;

            foreach (Wheel weel in m_Weels)
            {
                weel.MaximumAirPressure = 28;
            }
        }

        //IMotor method's:
        public String LicenseType
        {
            set
            {
                if (value.Equals("A") || value.Equals("A1") || value.Equals("AA") || value.Equals("B"))
                {
                    m_LicenseType = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }

            get
            {
                return m_LicenseType;
            }
        }

        public int EngineCapacityInCc
        {
            set
            {
                if (value > 0)
                {
                    m_EngineCapacityInCc = value;
                }
                else
                {
                    throw new ValueOutOfRangeException("the value out of range");
                }
            }

            get
            {
                return m_EngineCapacityInCc;
            }
        }

        //IElectric method's:
        public float ChargeTimeRemindInHours
        {
            set
            {
                if (value > 0 && value <= MaxChargeTimePosibleInHours)
                {
                    m_ChargeTimeRemindInHours = value;
                    CalculatePercentagesOfEnergy();
                }
                else
                {
                    throw new ValueOutOfRangeException("the value out of range");
                }
            }

            get
            {
                return m_ChargeTimeRemindInHours;
            }
        }

        public float MaxChargeTimePosibleInHours
        {
            set
            {
                if (value > 0)
                {
                    m_MaxChargeTimePosibleInHours = value;
                }
                else
                {
                    throw new ValueOutOfRangeException("the values out of range");
                }
            }

            get
            {
                return m_MaxChargeTimePosibleInHours;
            }
        }

        public bool ToChargeUp(float i_HoursToChargeUp)
        {
            bool o_ChargeUpSeccsed = false;
            float chargeStateBefore = ChargeTimeRemindInHours;

            if (i_HoursToChargeUp > 0)
            {
                ChargeTimeRemindInHours += i_HoursToChargeUp;
                if (chargeStateBefore < ChargeTimeRemindInHours)
                {
                    o_ChargeUpSeccsed = true;
                }
                ///if we want help the user and dont throw exeption we will use this(make his charge full):
               /* else
                {
                    ChargeTimeRemindInHours += (MaxChargeTimePosibleInHours - ChargeTimeRemindInHours);
                    if (MaxChargeTimePosibleInHours < ChargeTimeRemindInHours)
                    {
                        o_ChargeUpSeccsed = true;
                    }
                }*/
            }

            return o_ChargeUpSeccsed;
        }

        bool IElectric.ToChargeUp(float i_HoursToChargeUp)//explicit implementation
        {
            return ToChargeUp(i_HoursToChargeUp);
        }

        //Vehicle method's:
        public override int SetAndGetNumberOfWeels()
        {
            m_NumberOfWeels = 2;

            return m_NumberOfWeels;
        }

        public override void CreateWeels()
        {
            SetAndGetNumberOfWeels();
            m_Weels = new List<Wheel>(m_NumberOfWeels * 2);

            for (int i = 0; i < m_NumberOfWeels; i++)
            {
                m_Weels.Add(new Wheel());
            }
        }

        public override float CalculatePercentagesOfEnergy()
        {
            float o_PresentOfEnergy = -1;
            if (MaxChargeTimePosibleInHours != 0)
            {
                o_PresentOfEnergy = ChargeTimeRemindInHours * 100 / MaxChargeTimePosibleInHours;
                EnergyPresent = o_PresentOfEnergy;
            }

            return o_PresentOfEnergy;
        }

        public override float GetMaxAirPressure()
        {
            return m_Weels[0].MaximumAirPressure;
        }
    }
}
