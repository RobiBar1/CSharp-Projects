﻿using System;

namespace Ex03.GarageLogic
{
    public interface IElectric
    {
        float ChargeTimeRemindInHours
        {
            set;
            get;
        }

        float MaxChargeTimePosibleInHours
        {
            set;
            get;
        }

        bool ToChargeUp(float i_HoursToChargeUp);
    }
}
