﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex03.GarageLogic
{
    public class ValueOutOfRangeException : Exception
    {
        private float m_MinValue;
        private float m_MaxValue;//i dont see a reason to use this varibles becuase i cheack on fuel propties
                                 //if input is valid, so i keep it private without do any propties to this members
        public ValueOutOfRangeException() { }

        public ValueOutOfRangeException(String message) : base(message) { }

        public ValueOutOfRangeException(String message, Exception inner) : base(message, inner) { }
    }
}
