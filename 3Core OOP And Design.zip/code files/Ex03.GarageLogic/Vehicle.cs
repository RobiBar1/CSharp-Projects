﻿using System;
using System.Collections.Generic;

namespace Ex03.GarageLogic
{
    public abstract class Vehicle
    {
        private String m_ModelName;
        private String m_LicensePlate;
        private float m_EnergyPresent;
        protected int m_NumberOfWeels;
        protected List<Wheel> m_Weels;

        public String ModelName
        {
            set
            {
                m_ModelName = value;
            }

            get
            {
                return m_ModelName;
            }
        }

        public String LicensePlate
        {
            set
            {
                m_LicensePlate = value;
            }
            get
            {
                return m_LicensePlate;
            }
        }

        public float EnergyPresent
        {
            set
            {
                if (value >= 0 &&   value <= 100)
                {
                    m_EnergyPresent = value;
                }
            }

            get
            {
                return m_EnergyPresent;
            }
        }

        public bool InflatingAllWheels(float i_NumberOfAirToAdd)
        {
            int count = 0;
            bool o_InflatingALLWheelsSeccsed = false;
            foreach (Wheel weel in m_Weels)
            {
                if(weel.InflatingAWheel(i_NumberOfAirToAdd))
                {
                    count++;
                }
            }

            if(count == m_Weels.Count)
            {
                o_InflatingALLWheelsSeccsed = true;
            }

            return o_InflatingALLWheelsSeccsed;
        }

        public abstract int SetAndGetNumberOfWeels();

        public abstract void CreateWeels();

        public abstract float CalculatePercentagesOfEnergy();

        public abstract float GetMaxAirPressure();
    }
}
