﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex03.GarageLogic
{
    public class Wheel
    {
        private String m_ManufacturerName;
        private float m_CurrentAirPressure;
        private float m_MaximumAirPressure;

        public String ManufacturerName
        {
            set
            {
                m_ManufacturerName = value;
            }

            get
            {
                return m_ManufacturerName;
            }
        }

        public float CurrentAirPressure
        {
            set
            {
                if (value > 0 && value <= m_MaximumAirPressure)
                {
                    m_CurrentAirPressure = value;
                }
                else
                {
                    throw new ValueOutOfRangeException("Value out of range");
                }
            }

            get
            {
                return m_CurrentAirPressure;
            }
        }

        public float MaximumAirPressure
        {
            set
            {
                if (value > 0)
                {
                    m_MaximumAirPressure = value;
                }
                else
                {
                    throw new ValueOutOfRangeException("Value must be ");
                }
            }

            get
            {
                return m_MaximumAirPressure;
            }
        }

        public bool InflatingAWheel(float i_NumberOfAirToAdd)
        {
            float beforeInflating = CurrentAirPressure;
            bool o_InflatingHappned = false;

            if (CurrentAirPressure + i_NumberOfAirToAdd <= MaximumAirPressure)
            {
                CurrentAirPressure += i_NumberOfAirToAdd;
                if (beforeInflating < CurrentAirPressure)
                {
                    o_InflatingHappned = true;
                }
            }
            else
            {
                CurrentAirPressure += (MaximumAirPressure - CurrentAirPressure);
                if (beforeInflating < CurrentAirPressure)
                {
                    o_InflatingHappned = true;
                }
            }

            return o_InflatingHappned;
        }

        public bool InflatingAWheelToMax()
        {
            return InflatingAWheel(MaximumAirPressure);
        }
    }
}
