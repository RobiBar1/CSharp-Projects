﻿using System;

namespace Ex03.GarageLogic
{
    public interface IFuel
    {
        String FuelType
        {
            set;
            get;
        }

        float CurrentLiters
        {
            set;
            get;
        }

        float MaxLitersPossible
        {
            set;
            get;
        }

        bool ToGasUp(float i_LitersToGasUp, String i_TypeOfFuel);
    }
}
