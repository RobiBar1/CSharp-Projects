﻿using System;
using System.Collections.Generic;

namespace Ex03.GarageLogic
{
    public class GarageManger
    {
        public enum VehicleWeSuuportEnum
        {
            Motor = 1,
            ElectricMotor,
            Car,
            ElectricCar,
            Truck
        }
        
        public Vehicle CreateNewVehicle(VehicleWeSuuportEnum i_WhoToCreate)
        {
            Vehicle o_vehicleToReturn = new MotorFuel();

            switch (i_WhoToCreate)
            {
                case VehicleWeSuuportEnum.Motor:
                    break;

                case VehicleWeSuuportEnum.ElectricMotor:
                    o_vehicleToReturn = new MotorElectirc();
                    break;

                case VehicleWeSuuportEnum.Car:
                    o_vehicleToReturn = new CarFuel();
                    break;

                case VehicleWeSuuportEnum.ElectricCar:
                    o_vehicleToReturn = new CarElectric();
                    break;

                case VehicleWeSuuportEnum.Truck:
                    o_vehicleToReturn = new TruckFuel();
                    break;

                default:
                    o_vehicleToReturn = null;
                    break;
            }

            return o_vehicleToReturn;
        }
    }
}
