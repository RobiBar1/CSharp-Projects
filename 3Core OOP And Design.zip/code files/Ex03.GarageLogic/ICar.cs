﻿using System;

namespace Ex03.GarageLogic
{
    public interface ICar
    {
        String Color
        {
            get;
            set;
        }

        int DoorsNumber
        {
            get;
            set;
        }
    }
}
