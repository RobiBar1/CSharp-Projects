﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex03.GarageLogic
{
    public class MotorFuel : Vehicle, IFuel, IMotor
    {
        //IMotor varibles:
        private String m_LicenseType = "None";
        private int m_EngineCapacityInCc;
        //fuel varibles:
        private String m_FuelType = "None";
        private float m_CurrentLiters;
        private float m_MaxLitersPossible;
        

        //MotorFuel method's:
        public MotorFuel()
        {
            CreateWeels();
            FuelType = "Octan98";
            MaxLitersPossible = 6;

            foreach (Wheel weel in m_Weels)
            {
                weel.MaximumAirPressure = 28;
            }
        }

        //IMotor method's:
        public String LicenseType
        {
            set
            {
                if (value.Equals("A") || value.Equals("A1") || value.Equals("AA") || value.Equals("B"))
                {
                    m_LicenseType = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }

            get
            {
                return m_LicenseType;
            }
        }

        public int EngineCapacityInCc
        {
            set
            {
                if(value > 0)
                {
                    m_EngineCapacityInCc = value;
                }
                else
                {
                    throw new ValueOutOfRangeException("the value out of range");
                }
            }

            get
            {
                return m_EngineCapacityInCc;
            }
        }

        //IFuel method's:
        public String FuelType
        {
            set
            {
                if (value.Equals("Soler") || value.Equals("Octan95") || value.Equals("Octan96") || value.Equals("Octan98"))
                {
                    m_FuelType = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
            get
            {
                return m_FuelType;
            }
        }

        public float CurrentLiters
        {
            set
            {
                if (value > 0 && value <= m_MaxLitersPossible)
                {
                    m_CurrentLiters = value;
                    CalculatePercentagesOfEnergy();
                }
                else
                {
                    throw new ValueOutOfRangeException("the value out of range");
                }
            }

            get
            {
                return m_CurrentLiters;
            }
        }

        public float MaxLitersPossible
        {
            set
            {
                if (value > 0)
                {
                    m_MaxLitersPossible = value;
                }
                else
                {
                    throw new ValueOutOfRangeException("the value out of range");
                }
            }

            get
            {
                return m_MaxLitersPossible;
            }
        }

        public bool ToGasUp(float i_LitersToGasUp, String i_TypeOfFuel)
        {
            bool o_GasUpSeccsed = false;
            float litersBefore = CurrentLiters;
            if (i_TypeOfFuel.Equals(FuelType) && i_LitersToGasUp > 0)
            {
                CurrentLiters += i_LitersToGasUp;
                if (litersBefore < CurrentLiters)
                {
                    o_GasUpSeccsed = true;
                }
                ///if we want help the user and dont throw exeption we will use this(make his charge full):
                /*else
                {
                    CurrentLiters += (MaxLitersPossible - CurrentLiters);
                    if (MaxLitersPossible < CurrentLiters)
                    {
                        o_GasUpSeccsed = true;
                    }
                }*/
            }

            return o_GasUpSeccsed;
        }

        bool IFuel.ToGasUp(float i_LitersToGasUp, string i_TypeOfFuel)//explicit implementation
        {
            return ToGasUp(i_LitersToGasUp, i_TypeOfFuel);
        }

        //Vehicle method's:
        public override int SetAndGetNumberOfWeels()
        {
            m_NumberOfWeels = 2;
            
            return m_NumberOfWeels;
        }

        public override void CreateWeels()
        {
            SetAndGetNumberOfWeels();
            m_Weels = new List<Wheel>(m_NumberOfWeels * 2);

            for (int i = 0; i < m_NumberOfWeels; i++)
            {
                m_Weels.Add(new Wheel());
            }
        }

        public override float CalculatePercentagesOfEnergy()
        {

            float o_PresentOfEnergy = -1;
            if (MaxLitersPossible != 0)
            {
                o_PresentOfEnergy =  CurrentLiters * 100 / MaxLitersPossible;
                EnergyPresent = o_PresentOfEnergy;
            }

            return o_PresentOfEnergy;
        }

        public override float GetMaxAirPressure()
        {
            return m_Weels[0].MaximumAirPressure;
        }
    }
}
