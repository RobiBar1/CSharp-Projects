﻿using System;
using System.Collections.Generic;
using Ex03.GarageLogic;
namespace Ex03.ConsoleUI
{
    class Person
    {
        private CarsInGarageDetailes m_Detail;
        private String m_WhatVehicleDoIHave = "None";
        private Vehicle m_MyVehicle;

        public Person(String i_VehicleToCreate)
        {
            while (WhatVehicleDoIHave.Equals("None"))
            {
                try
                {
                    WhatVehicleDoIHave = i_VehicleToCreate;
                }
                catch(ArgumentException e) 
                {
                    Console.WriteLine(String.Format("Exepetion: {0}, try again", e.Message));
                    i_VehicleToCreate = Console.ReadLine();
                }
            }

            m_Detail = new CarsInGarageDetailes();
            GarageManger manger = new GarageManger();
            foreach (GarageManger.VehicleWeSuuportEnum vehicle in (GarageManger.VehicleWeSuuportEnum[])
                                            Enum.GetValues(typeof(GarageManger.VehicleWeSuuportEnum)))
            {
                if (i_VehicleToCreate.Equals(vehicle.ToString()))
                {
                    m_MyVehicle = manger.CreateNewVehicle(vehicle);
                    break;
                }
            }
        }
        
        public CarsInGarageDetailes Detail
        {
            set
            {
                m_Detail.OwnerName = value.OwnerName;
                m_Detail.OwnerPhone = value.OwnerPhone;
                m_Detail.VehicleState = value.VehicleState;
            }

            get
            {
                return m_Detail;
            }
        }

        public String WhatVehicleDoIHave
        {
            set
            {
                if (Enum.IsDefined(typeof(GarageManger.VehicleWeSuuportEnum), value))
                {
                    m_WhatVehicleDoIHave = value;
                }
                else
                {
                    throw new ArgumentException("the value is ");
                }
            }
            
            get
            {
                return m_WhatVehicleDoIHave;
            }
        }
        public Vehicle MyVehicle
        {
            get
            {
                return m_MyVehicle;
            }
        }
    }
}
