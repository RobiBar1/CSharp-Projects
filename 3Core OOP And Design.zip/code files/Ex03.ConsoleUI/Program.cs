﻿using System;
using System.Collections.Generic;
using Ex03.GarageLogic;

//The code throws all the exceptions that were required, also, they are never caught because it was not clear
//if we were required for this, if it was required for catch it or if I would have written the code as I want
//I was add:
//Catches the exceptions in the part of the UI and prints the message to the user in the console.
namespace Ex03.ConsoleUI
{
    class Program
    {
        private static Dictionary<int, Person> m_LicensePlateInTheCollection = new Dictionary<int, Person>();

        public static void Main(String[] args)
        {
            //***************************************************************************************************
            Person usr1 = new Person("Car");
            usr1.Detail.OwnerName = "Robi1";
            usr1.Detail.OwnerPhone = "1111111";
            usr1.MyVehicle.InflatingAllWheels(30);
            usr1.MyVehicle.LicensePlate = "1";
            usr1.MyVehicle.ModelName = "Car";
            (usr1.MyVehicle as IFuel).CurrentLiters = 40;
            (usr1.MyVehicle as ICar).Color = "Red";
            (usr1.MyVehicle as ICar).DoorsNumber = 3;

            Person usr2 = new Person("Motor");
            usr2.Detail.OwnerName = "Robi2";
            usr2.Detail.OwnerPhone = "22222";
            usr2.MyVehicle.InflatingAllWheels(25);
            usr2.MyVehicle.LicensePlate = "2";
            usr2.MyVehicle.ModelName = "Motor";
            (usr2.MyVehicle as IFuel).CurrentLiters = 5;
            (usr2.MyVehicle as IMotor).LicenseType= "A";
            (usr2.MyVehicle as IMotor).EngineCapacityInCc= 15;

            Person usr3 = new Person("Truck");
            usr3.Detail.OwnerName = "Robi3";
            usr3.Detail.OwnerPhone = "3333333";
            usr3.MyVehicle.InflatingAllWheels(32);
            usr3.MyVehicle.LicensePlate = "3";
            usr3.MyVehicle.ModelName = "Truck";
            (usr3.MyVehicle as IFuel).CurrentLiters = 5;
            (usr3.MyVehicle as ITruck).HaveHazardousMaterials = true;
            (usr3.MyVehicle as ITruck).CargoCapacity = 123;

            Person usr4 = new Person("ElectricCar");
            usr4.Detail.OwnerName = "Robi4";
            usr4.Detail.OwnerPhone = "44444444";
            usr4.MyVehicle.InflatingAllWheels(32);
            usr4.MyVehicle.LicensePlate = "4";
            usr4.MyVehicle.ModelName = "ElectrickCar";
            (usr4.MyVehicle as IElectric).ChargeTimeRemindInHours = 1;
            (usr4.MyVehicle as ICar).Color = "Red";
            (usr4.MyVehicle as ICar).DoorsNumber = 3;

            
            Person usr5 = new Person("ElectricMotor");
            usr5.Detail.OwnerName = "Robi5";
            usr5.Detail.OwnerPhone = "555555";
            usr5.MyVehicle.InflatingAllWheels(15);
            usr5.MyVehicle.LicensePlate = "5";
            usr5.MyVehicle.ModelName = "ElectricMotor";
            (usr5.MyVehicle as IElectric).ChargeTimeRemindInHours = 1;
            (usr5.MyVehicle as IMotor).LicenseType = "A";
            (usr5.MyVehicle as IMotor).EngineCapacityInCc = 15;

            m_LicensePlateInTheCollection.Add(usr1.MyVehicle.LicensePlate.GetHashCode(), usr1);
            m_LicensePlateInTheCollection.Add(usr2.MyVehicle.LicensePlate.GetHashCode(), usr2);
            m_LicensePlateInTheCollection.Add(usr3.MyVehicle.LicensePlate.GetHashCode(), usr3);
            m_LicensePlateInTheCollection.Add(usr4.MyVehicle.LicensePlate.GetHashCode(), usr4);
            m_LicensePlateInTheCollection.Add(usr5.MyVehicle.LicensePlate.GetHashCode(), usr5);

            bool wantToKeepUsingGarage = true;
            Console.WriteLine(String.Format("Welcome to the garage, for your convenience I have" +
                    " already put 5 vehicles (1 of each type) into the garage.{0}You are welcome to" +
                    " get their data from function number 7 and work with them," +
                    " or of course put new vehicles{0}into the garage with function number 1, enjoy!",
                    System.Environment.NewLine));
            while (wantToKeepUsingGarage)
            {
                bool validInput = false;
                while (!validInput)
                {
                    Console.WriteLine(String.Format("enter number of function" +
                        " you want to use(1 - 7) or (q) for exit: "));
                    String usrInputString = Console.ReadLine();
                    if (int.TryParse(usrInputString, out int usrInputInInt))
                    {
                        if(usrInputInInt >= 1 && usrInputInInt <= 7)
                        {
                            try
                            {
                                if (usrInputInInt == 1)
                                {
                                    EnterToGarage();
                                    validInput = true;
                                }
                                else if (usrInputInInt == 2)
                                {
                                    ShowLicensePlateInTheGarage();
                                    validInput = true;
                                }
                                else if (usrInputInInt == 3)
                                {
                                    ChangeStateOfVehicleInTheGarage();
                                    validInput = true;
                                }
                                else if (usrInputInInt == 4)
                                {
                                    InflatingAllWeelsToMax();
                                    validInput = true;
                                }
                                else if (usrInputInInt == 5)
                                {
                                    ToGasUpFuelVehicle();
                                    validInput = true;
                                }
                                else if (usrInputInInt == 6)
                                {
                                    ToChargeUpVehicle();
                                    validInput = true;
                                }
                                else if (usrInputInInt == 7)
                                {
                                    PrintVehicleFullDetails();
                                    validInput = true;
                                }
                            }
                            catch(FormatException e)
                            {
                                Console.WriteLine(string.Format("Exeption: {0}",e.Message));
                                continue;
                            }
                            catch(ValueOutOfRangeException e)
                            {
                                Console.WriteLine(string.Format("Exeption: {0}", e.Message));
                                continue;
                            }
                            catch(ArgumentException e)
                            {
                                Console.WriteLine(string.Format("Exeption: {0}", e.Message));
                                continue;
                            }
                            catch(Exception e)
                            {
                                Console.WriteLine(string.Format("Exeption: {0}", e.Message));
                                continue;
                            }
                        }
                        else
                        {
                            Console.WriteLine("only here(not in the matala functions) we dont throw exeption, try again with numbers 1 - 7 only");
                        }
                    }
                    else if(usrInputString.Equals("q") || usrInputString.Equals("Q"))
                    {
                        wantToKeepUsingGarage = false;
                        break;
                    }
                    else
                    {
                        Console.WriteLine("only here(not in the matala functions) we dont throw exeption, try again with numbers only");
                    }
                }
            }

            Console.WriteLine("Bye Bye");
            Console.WriteLine("Press enter to continue");
            Console.ReadLine();
        }

        public static void EnterToGarage()//throw FormatException
        {
            Console.WriteLine("Enter the License Plate: ");
            string CurrentLicensePlate = Console.ReadLine();
            bool isNewCar = true;

            foreach (int LicensePlate in m_LicensePlateInTheCollection.Keys)
            {
                if (CurrentLicensePlate.GetHashCode() == LicensePlate)
                {
                    Console.WriteLine("Your vehicle already in the garage, and we now pass his state to 'UnderRepair'");
                    Person existCar = m_LicensePlateInTheCollection[LicensePlate];
                    existCar.Detail.VehicleState = "UnderRepair";
                    isNewCar = false;
                }
            }

            if (isNewCar)//create Person and full his vehicle.
            {
                bool isValidInput = false;
                bool firstPrint = true;
                Console.Write("Please enter the kind of vehicle you want enter to the garage(");
                foreach (GarageManger.VehicleWeSuuportEnum vehicle in (GarageManger.VehicleWeSuuportEnum[])
                                                Enum.GetValues(typeof(GarageManger.VehicleWeSuuportEnum)))
                {
                    if (firstPrint)
                    {
                        Console.Write(String.Format("{0}", vehicle));
                        firstPrint = false;
                        continue;
                    }
                    Console.Write(String.Format(", {0}", vehicle));
                }
                Console.WriteLine("): ");
                Person customer = new Person(Console.ReadLine());
                String myVehicle = customer.MyVehicle.ModelName = customer.WhatVehicleDoIHave;
                String userInput;
                float userInputsFloat;
                int userInputsInt;

                customer.MyVehicle.LicensePlate = CurrentLicensePlate;
                while (!isValidInput)//Vehicle parameter's:
                {
                    Console.WriteLine(string.Format("Enter the air pressure state(number from 0 - {0})",
                        customer.MyVehicle.GetMaxAirPressure()));
                    userInput = Console.ReadLine();
                    if (float.TryParse(userInput, out userInputsFloat))
                    {
                        try
                        {
                            if (!(customer.MyVehicle.InflatingAllWheels(userInputsFloat)))
                            {
                                Console.WriteLine("The air pressure you entered is invalid, try again");
                            }
                            else
                            {
                                isValidInput = true;
                            }
                        }
                        catch(ValueOutOfRangeException e)
                        {
                            Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                            continue;
                        }
                    }
                    else
                    {
                        //Console.WriteLine("The air pressure you entered is invalid, try again");
                        throw new FormatException();
                    }
                }

                isValidInput = false;
                if (checkIfFuelType(customer))//IFuel parameter's:
                {
                    while (!isValidInput)
                    {
                        Console.WriteLine(string.Format("Enter the fuel state(number from 0 - {0})",
                            (customer.MyVehicle as IFuel).MaxLitersPossible));
                        userInput = Console.ReadLine();
                        if (float.TryParse(userInput, out userInputsFloat))
                        {
                            try
                            {
                                if (!((customer.MyVehicle as IFuel).ToGasUp(userInputsFloat,
                                    (customer.MyVehicle as IFuel).FuelType)))
                                {
                                    Console.WriteLine("The fuel state you entered is invalid, try again");
                                }
                                else
                                {
                                    isValidInput = true;
                                }
                            }
                            catch (ValueOutOfRangeException e)
                            {
                                Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                                continue;
                            }
                        }
                        else
                        {
                            throw new FormatException();
                        }
                    }

                    isValidInput = false;
                }
                
                else if (checkIfElectricType(customer))//IElectric parameter's:
                {
                    while (!isValidInput)
                    {
                        Console.WriteLine(string.Format("Enter the charging state of the vehicle(number from 0 - {0} Hours)",
                            (customer.MyVehicle as IElectric).MaxChargeTimePosibleInHours));
                        userInput = Console.ReadLine();
                        
                        if (float.TryParse(userInput, out userInputsFloat))
                        {
                            try
                            {
                                if (!((customer.MyVehicle as IElectric).ToChargeUp(userInputsFloat)))
                                {
                                    Console.WriteLine("The charging state you entered is invalid, try again");
                                }
                                else
                                {
                                    isValidInput = true;
                                }
                            }
                            catch (ValueOutOfRangeException e)
                            {
                                Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                                continue;
                            }
                        }
                        else
                        {
                            throw new FormatException();
                        }
                    }

                    isValidInput = false;
                }

                if (myVehicle.Equals("Motor") || myVehicle.Equals("ElectricMotor"))//Specific details for motor's
                {
                    while (!isValidInput)
                    {
                        Console.WriteLine("Enter your license type(A, A1, AA, B)");
                        userInput = Console.ReadLine();
                        String licenseTypeBefore = (customer.MyVehicle as IMotor).LicenseType;
                        try
                        {
                            (customer.MyVehicle as IMotor).LicenseType = userInput;
                            if ((customer.MyVehicle as IMotor).LicenseType.Equals(licenseTypeBefore))
                            {
                                Console.WriteLine("The license type you entered is invalid, try again");
                            }
                            else
                            {
                                isValidInput = true;
                            }
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                            continue;
                        }
                    }

                    isValidInput = false;
                    while (!isValidInput)
                    {
                        Console.WriteLine("Enter your engine capacity in cc(positive and complete number's only)");
                        userInput = Console.ReadLine();
                        int EngineCapacityBefore = (customer.MyVehicle as IMotor).EngineCapacityInCc;
                        if (int.TryParse(userInput, out userInputsInt))
                        {
                            try
                            {
                                (customer.MyVehicle as IMotor).EngineCapacityInCc = userInputsInt;
                                if ((customer.MyVehicle as IMotor).EngineCapacityInCc.Equals(EngineCapacityBefore))
                                {
                                    Console.WriteLine("The engine capacity you entered is invalid, try again");
                                }
                                else
                                {
                                    isValidInput = true;
                                }
                            }
                            catch (ValueOutOfRangeException e)
                            {
                                Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                                continue;
                            }
                        }
                        else
                        {
                            throw new FormatException();
                        }
                    }
                }
                else if (myVehicle.Equals("Car") || myVehicle.Equals("ElectricCar"))//Specific details for Car's
                {
                    while (!isValidInput)
                    {
                        Console.WriteLine("Enter the car color(Red, Blue, White, Grey)");
                        userInput = Console.ReadLine();
                        String colorBefore = (customer.MyVehicle as ICar).Color;
                        try
                        {
                            (customer.MyVehicle as ICar).Color = userInput;
                            if ((customer.MyVehicle as ICar).Color.Equals(colorBefore))
                            {
                                Console.WriteLine("The car color you entered is invalid, try again");
                            }
                            else
                            {
                                isValidInput = true;
                            }
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                            continue;
                        }
                    }

                    isValidInput = false;
                    while (!isValidInput)
                    {
                        Console.WriteLine("Enter the number of doors im your car (2 - 5)");
                        userInput = Console.ReadLine();
                        int doorsNumberBefore = (customer.MyVehicle as ICar).DoorsNumber;
                        if (int.TryParse(userInput, out userInputsInt))
                        {
                            try
                            {
                                (customer.MyVehicle as ICar).DoorsNumber = userInputsInt;
                                if ((customer.MyVehicle as ICar).DoorsNumber.Equals(doorsNumberBefore))
                                {
                                    Console.WriteLine("The number of doors you entered is invalid, try again");
                                }
                                else
                                {
                                    isValidInput = true;
                                }
                            }
                            catch (ValueOutOfRangeException e)
                            {
                                Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                                continue;
                            }
                        }
                        else
                        {
                            throw new FormatException();
                        }
                    }
                }
                else if (myVehicle.Equals("Truck"))//Specific details for Truck's
                {
                    while (!isValidInput)
                    {
                        Console.WriteLine("The truck have dangerous materials?(Yes, No)");
                        userInput = Console.ReadLine();
                        if (userInput.Equals("Yes"))
                        {
                            (customer.MyVehicle as TruckFuel).HaveHazardousMaterials = true;
                            isValidInput = true;
                        }
                        else if (userInput.Equals("No"))
                        {
                            (customer.MyVehicle as TruckFuel).HaveHazardousMaterials = false;
                            isValidInput = true;
                        }
                        else
                        {
                            Console.WriteLine("The number of doors you entered is invalid, try again");
                        }
                    }

                    isValidInput = false;
                    while (!isValidInput)
                    {
                        Console.WriteLine("Enter your cargo capacity (positive number's only)");
                        userInput = Console.ReadLine();
                        float EngineCapacityBefore = (customer.MyVehicle as TruckFuel).CargoCapacity;
                        if (float.TryParse(userInput, out userInputsFloat))
                        {
                            try
                            {
                                (customer.MyVehicle as TruckFuel).CargoCapacity = userInputsFloat;
                                if ((customer.MyVehicle as TruckFuel).CargoCapacity.Equals(EngineCapacityBefore))
                                {
                                    Console.WriteLine("The cargo capacity you entered is invalid, try again");
                                }
                                else
                                {
                                    isValidInput = true;
                                }
                            }
                            catch (ValueOutOfRangeException e)
                            {
                                Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                                continue;
                            }
                        }
                        else
                        {
                            throw new FormatException();
                        }
                    }
                }

                Console.WriteLine("Please enter the vehicle owner's name: ");
                customer.Detail.OwnerName = Console.ReadLine();
                isValidInput = false;
                while (!isValidInput)
                {
                    Console.WriteLine("Please enter the vehicle owner's phone number(positive numbers only): ");
                    String beforePhone = customer.Detail.OwnerPhone;
                    try
                    {
                        customer.Detail.OwnerPhone = Console.ReadLine();
                        if (!customer.Detail.OwnerPhone.Equals(beforePhone))
                        {
                            isValidInput = true;
                        }
                        else
                        {
                            Console.WriteLine("The phone number is invalid, try again");
                        }
                    }
                    catch (ValueOutOfRangeException e)
                    {
                        Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                        continue;
                    }
                    catch (FormatException e)
                    {
                        Console.WriteLine(String.Format("Exeption: {0}, try again", e.Message));
                        continue;
                    }
                }
                m_LicensePlateInTheCollection.Add(customer.MyVehicle.LicensePlate.GetHashCode(), customer);
            }
        }

        public static void ShowLicensePlateInTheGarage()
        {
            String seeOnly = "none";

            while (!seeOnly.Equals("All") && !seeOnly.Equals("UnderRepair") && !seeOnly.Equals("Fixed")
                                         && !seeOnly.Equals("PaidUp"))
            {
                Console.WriteLine(String.Format("How do you want filter the reasult, by: " +
                    "(UnderRepair, Fixed, PaidUp, All)"));
                seeOnly = Console.ReadLine();
            }
            if (seeOnly.Equals("All"))
            {
                if (m_LicensePlateInTheCollection.Count == 0)
                {
                    Console.WriteLine("The garage is empty");
                }
                else
                {
                    Console.WriteLine("The list off All License plate: ");
                    foreach (Person item in m_LicensePlateInTheCollection.Values)
                    {
                        Console.WriteLine(item.MyVehicle.LicensePlate);
                    }
                }
            }
            else
            {
                bool happnedOnes = false;
                foreach (Person item in m_LicensePlateInTheCollection.Values)
                {
                    if (item.Detail.VehicleState.Equals(seeOnly))
                    {
                        Console.WriteLine(item.MyVehicle.LicensePlate);
                        happnedOnes = true;
                    }
                }

                if (!happnedOnes)
                {
                    if (m_LicensePlateInTheCollection.Count == 0)
                    {
                        Console.WriteLine("The garage is complete empty");
                    }
                    else
                    {
                        Console.WriteLine(string.Format("The garage is empty of that kind of filter, but not " +
                            "copmlete empty, try serch with other filter :-)"));
                    }
                }
            }
        }

        public static bool ChangeStateOfVehicleInTheGarage()
        {
            bool o_ChangeWasSucceeded = false;
            bool invaludInput = true;

            Console.WriteLine("Enter the license plate of the vihecle do you want to change his state: ");
            String CurrentLicensePlate = Console.ReadLine();
            foreach (int LicensePlate in m_LicensePlateInTheCollection.Keys)
            {
                if (CurrentLicensePlate.GetHashCode() == LicensePlate)
                {
                    Person existCar = m_LicensePlateInTheCollection[LicensePlate];
                    String stateBefore = existCar.Detail.VehicleState;
                    while (invaludInput)
                    {
                        Console.WriteLine("What the state do you want you'r vehicle will be? (UnderRepair, Fixed, PaidUp)");
                        existCar.Detail.VehicleState = Console.ReadLine();
                        if (existCar.Detail.VehicleState.Equals(stateBefore))
                        {
                            Console.WriteLine("Invalid input, be attention that you must change the state to NEW state");
                        }
                        else
                        {
                            invaludInput = false;
                            o_ChangeWasSucceeded = true;
                        }
                    }
                }
            }

            if (!o_ChangeWasSucceeded)
            {
                Console.WriteLine(String.Format("Your vehicle aren't in the garage, so we could not do changes," +
                    " try enter the vehicle to the garage first :-)"));
            }

            return o_ChangeWasSucceeded;
        }

        public static bool InflatingAllWeelsToMax()
        {
            bool o_ChangeWasSucceeded = false;
            Console.WriteLine("Enter the license plate of the vehicle that you want to inflatin his wheels: ");
            String CurrentLicensePlate = Console.ReadLine();
            foreach (int LicensePlate in m_LicensePlateInTheCollection.Keys)
            {
                if (CurrentLicensePlate.GetHashCode() == LicensePlate)
                {
                    Person existCar = m_LicensePlateInTheCollection[LicensePlate];
                    o_ChangeWasSucceeded = existCar.MyVehicle.InflatingAllWheels(existCar.MyVehicle.GetMaxAirPressure());
                }
            }

            if (!o_ChangeWasSucceeded)
            {
                Console.WriteLine(String.Format("Your vehicle aren't in the garage, so we could not inflaing the wheels," +
                    " try enter the vehicle to the garage first :-)"));
            }
            else
            {
                Console.WriteLine(String.Format("Your wheels is now full!"));
            }

            return o_ChangeWasSucceeded;
        }

        public static bool ToGasUpFuelVehicle()
        {
            bool o_ChangeWasSucceeded = false;
            bool vehicleFuelType = true;
            String CurrentLicensePlate;

            Console.WriteLine("Enter the license plate of the vehicle you want to gas up: ");
            CurrentLicensePlate = Console.ReadLine();
            foreach (int LicensePlate in m_LicensePlateInTheCollection.Keys)
            {
                if (CurrentLicensePlate.GetHashCode() == LicensePlate)
                {
                    Person existVehicle = m_LicensePlateInTheCollection[LicensePlate];
                    String typeOfExistVehicle = existVehicle.WhatVehicleDoIHave;

                    if (checkIfFuelType(existVehicle))
                    {
                        while (!o_ChangeWasSucceeded)
                        {
                            String typeToGasUp;
                            String valueToGasUp;

                            Console.WriteLine(String.Format("How much liters do you want to gas up?" +
                                "(0 - {0})", (existVehicle.MyVehicle as IFuel).MaxLitersPossible));
                            valueToGasUp = Console.ReadLine();
                            Console.WriteLine(String.Format("What the kind of fuel do you want to gas up?" +
                            "(Octan95, Octan96, Octan98, Soler), [your vehicle have {0} type]"
                            , (existVehicle.MyVehicle as IFuel).FuelType));
                            typeToGasUp = Console.ReadLine();
                            if (float.TryParse(valueToGasUp,out float valueToGasUpInFloat))
                            {
                                if (typeToGasUp.Equals((existVehicle.MyVehicle as IFuel).FuelType))
                                {
                                    float fuelWasBeforeWeGasUp = (existVehicle.MyVehicle as IFuel).CurrentLiters;
                                    o_ChangeWasSucceeded = (existVehicle.MyVehicle as IFuel).
                                        ToGasUp(valueToGasUpInFloat, typeToGasUp);
                                    if (o_ChangeWasSucceeded)
                                    {
                                        Console.WriteLine(String.Format("The car was fueled and now have {0} fuel!",
                                            (existVehicle.MyVehicle as IFuel).CurrentLiters));
                                        continue;
                                    }
                                    else if((existVehicle.MyVehicle as IFuel).CurrentLiters == 
                                            (existVehicle.MyVehicle as IFuel).MaxLitersPossible)
                                    {
                                        Console.WriteLine(String.Format("Your fuel tank has {0} liters, and you want to add" +
                                            " more {1} liters! {2}That's more than your fuel tank can hold," +
                                            " so we've only added {3} liters to your fuel tank, have a nice day :-)",
                                            fuelWasBeforeWeGasUp, valueToGasUpInFloat, System.Environment.NewLine,
                                            (existVehicle.MyVehicle as IFuel).MaxLitersPossible - fuelWasBeforeWeGasUp));
                                        o_ChangeWasSucceeded = true;
                                    }
                                    else
                                    {
                                        Console.WriteLine("invalid liters input, enter positive numbers only, try again ");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(String.Format("The type of fuel you want to gas up most be " +
                                        "the type of fuel of vehicle, try again"));
                                }
                            }
                            else
                            {
                                Console.WriteLine("invalid liters input, enter positive numbers only, try again ");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Your vehicle does not run on gas, therefore we cannot refuel it");
                        vehicleFuelType = false;
                        break;
                    }
                }
            }

            if (!o_ChangeWasSucceeded && vehicleFuelType)
            {
                Console.WriteLine("Your vehicle not in the garage, enter the vehicle to the garage and try again");
            }

            return o_ChangeWasSucceeded;
        }

        public static bool ToChargeUpVehicle()
        {
            bool o_ChangeWasSucceeded = false;
            bool vehicleElectricType = true;

            String CurrentLicensePlate;

            Console.WriteLine("Enter the license plate of the vehicle you want to charge up: ");
            CurrentLicensePlate = Console.ReadLine();
            foreach (int LicensePlate in m_LicensePlateInTheCollection.Keys)
            {
                if (CurrentLicensePlate.GetHashCode() == LicensePlate)
                {
                    Person existVehicle = m_LicensePlateInTheCollection[LicensePlate];
                    String typeOfExistVehicle = existVehicle.WhatVehicleDoIHave;

                    if (checkIfElectricType(existVehicle))
                    {
                        while (!o_ChangeWasSucceeded)
                        {
                            String valueToChargeInMin;

                            Console.WriteLine(String.Format("How much minutes do you want to charge up?" +
                                "(0 - {0})", (existVehicle.MyVehicle as IElectric).MaxChargeTimePosibleInHours * 60));
                            valueToChargeInMin = Console.ReadLine();
                            if (float.TryParse(valueToChargeInMin, out float valueToChargeUpInFloat))
                            {
                                float chargeWasBeforeInHours = (existVehicle.MyVehicle as IElectric).ChargeTimeRemindInHours;
                                o_ChangeWasSucceeded = (existVehicle.MyVehicle as IElectric).
                                    ToChargeUp(valueToChargeUpInFloat / 60);
                                if (o_ChangeWasSucceeded)
                                {
                                    Console.WriteLine(String.Format("The car was charged up and now have {0} Hours to drive!",
                                            (existVehicle.MyVehicle as IElectric).ChargeTimeRemindInHours));
                                    continue;
                                }
                                else if ((existVehicle.MyVehicle as IElectric).ChargeTimeRemindInHours ==
                                            (existVehicle.MyVehicle as IElectric).MaxChargeTimePosibleInHours)
                                {
                                    Console.WriteLine(String.Format("You had {0} minutes to drive, and you want to add" +
                                        " more {1} minutes! {2}That's more than you can charge to your vehicle " +
                                        "so we've only charge {3} minutes to your car, have a nice day :-)",
                                        chargeWasBeforeInHours * 60, valueToChargeUpInFloat, System.Environment.NewLine,
                                        ((existVehicle.MyVehicle as IElectric).MaxChargeTimePosibleInHours
                                        - chargeWasBeforeInHours) * 60));
                                    o_ChangeWasSucceeded = true;
                                }
                                else
                                {
                                    Console.WriteLine(String.Format("You entered negative number, " +
                                            "enter positive numbers only"));
                                }
                            }
                            else
                            {
                                Console.WriteLine("Invalid minutes input, enter positive numbers only, try again ");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Your vehicle does not run on electric, therefore we cannot charge it");
                        vehicleElectricType = false;
                        break;
                    }
                    if (o_ChangeWasSucceeded)
                    {
                        break;
                    }
                }
            }

            if(!o_ChangeWasSucceeded && vehicleElectricType)
            {
                Console.WriteLine("Your vehicle not in the garage, enter the vehicle to the garage and try again");
            }

            return o_ChangeWasSucceeded;
        }

        public static void PrintVehicleFullDetails()
        {
            bool isInTheGarage = false;
            Console.WriteLine("Enter the license plate of the vehicle that you want to see his details: ");
            String CurrentLicensePlate = Console.ReadLine();
            foreach (int LicensePlate in m_LicensePlateInTheCollection.Keys)
            {
                if (CurrentLicensePlate.GetHashCode() == LicensePlate)
                {
                    Person existVehicle = m_LicensePlateInTheCollection[LicensePlate];
                    Console.WriteLine(String.Format("The vehicle with licnse plate {0} details is: "
                        , CurrentLicensePlate));
                    PrintDetails(existVehicle);
                    isInTheGarage = true;
                    break;
                }
                
            }

            if (!isInTheGarage)
            {
                Console.WriteLine("Your vehicle not in the garage, enter the vehicle to the garage and try again");
            }
        }

        private static void PrintDetails(Person i_PersonWePrint)
        {
            Console.WriteLine("=======================================================================");
            Console.WriteLine(String.Format("Owner name:                                        {0}",
                i_PersonWePrint.Detail.OwnerName));
            Console.WriteLine();
            Console.WriteLine(String.Format("Owner phone:                                       {0}",
                i_PersonWePrint.Detail.OwnerPhone));
            Console.WriteLine();
            Console.WriteLine(String.Format("Vehicle state:                                     {0}",
                i_PersonWePrint.Detail.VehicleState));
            Console.WriteLine();
            Console.WriteLine(String.Format("Vehicle license plate:                             {0}",
                i_PersonWePrint.MyVehicle.LicensePlate));
            Console.WriteLine();
            Console.WriteLine(String.Format("Vehicle model name:                                {0}",
                i_PersonWePrint.MyVehicle.ModelName));
            Console.WriteLine();
            if (checkIfFuelType(i_PersonWePrint))
            {
                Console.WriteLine(String.Format("Vehicle fuel type:                                 {0}",
                    (i_PersonWePrint.MyVehicle as IFuel).FuelType));
                Console.WriteLine();
                Console.WriteLine(String.Format("Vehicle current liters:                            {0}",
                    (i_PersonWePrint.MyVehicle as IFuel).CurrentLiters));
                Console.WriteLine();
                Console.WriteLine(String.Format("Vehicle max liters:                                {0}",
                    (i_PersonWePrint.MyVehicle as IFuel).MaxLitersPossible));
                Console.WriteLine();
                Console.WriteLine(String.Format("current liters in present:                         {0}",
                    i_PersonWePrint.MyVehicle.EnergyPresent));
                Console.WriteLine();
            }
            else if(checkIfElectricType(i_PersonWePrint))
            {
                Console.WriteLine(String.Format("Vehicle charge time remind in hours:               {0}",
                    (i_PersonWePrint.MyVehicle as IElectric).ChargeTimeRemindInHours));
                Console.WriteLine();
                Console.WriteLine(String.Format("Vehicle max charge time in hours:                  {0}",
                    (i_PersonWePrint.MyVehicle as IElectric).MaxChargeTimePosibleInHours));
                Console.WriteLine();
                Console.WriteLine(String.Format("Charge time in present:                            {0}",
                    i_PersonWePrint.MyVehicle.EnergyPresent));
                Console.WriteLine();
            }

            if(checkIfMotorType(i_PersonWePrint))
            {
                Console.WriteLine(String.Format("Motor license typs is:                             {0}",
                    (i_PersonWePrint.MyVehicle as IMotor).LicenseType));
                Console.WriteLine();
                Console.WriteLine(String.Format("Motor Engine capacity in cc is:                    {0}",
                    (i_PersonWePrint.MyVehicle as IMotor).EngineCapacityInCc));
                Console.WriteLine();
            }
            else if(checkIfCarType(i_PersonWePrint))
            {
                Console.WriteLine(String.Format("Car color is:                                      {0}",
                    (i_PersonWePrint.MyVehicle as ICar).Color));
                Console.WriteLine();
                Console.WriteLine(String.Format("Car doors number is:                               {0}",
                    (i_PersonWePrint.MyVehicle as ICar).DoorsNumber));
                Console.WriteLine();
            }
            else if(checkIfTruckType(i_PersonWePrint))
            {
                Console.WriteLine(String.Format("Truck cargo capacity is:                           {0}",
                    (i_PersonWePrint.MyVehicle as ITruck).CargoCapacity));
                Console.WriteLine();
                Console.WriteLine(String.Format("The truck is transporting hazardous materials:     {0}",
                    (i_PersonWePrint.MyVehicle as ITruck).HaveHazardousMaterials));
                Console.WriteLine();
            }

            Console.WriteLine("=======================================================================");
        }

        private static bool checkIfFuelType(Person toCheck)
        {
            bool o_IsFuel = false;
            if(toCheck.WhatVehicleDoIHave.Equals("Motor") || toCheck.WhatVehicleDoIHave.Equals("Car")
                                                          || toCheck.WhatVehicleDoIHave.Equals("Truck"))
            {
                o_IsFuel = true;
            }

            return o_IsFuel;
        }

        private static bool checkIfElectricType(Person toCheck)
        {
            bool o_IsElectric = false;
            if (toCheck.WhatVehicleDoIHave.Equals("ElectricMotor") || toCheck.WhatVehicleDoIHave.Equals("ElectricCar"))                                            
            {
                o_IsElectric = true;
            }

            return o_IsElectric;
        }

        private static bool checkIfMotorType(Person toCheck)
        {
            bool o_IsMotor = false;
            if (toCheck.WhatVehicleDoIHave.Equals("ElectricMotor") || toCheck.WhatVehicleDoIHave.Equals("Motor"))
            {
                o_IsMotor = true;
            }

            return o_IsMotor;
        }

        private static bool checkIfCarType(Person toCheck)
        {
            bool o_IsElectric = false;
            if (toCheck.WhatVehicleDoIHave.Equals("Car") || toCheck.WhatVehicleDoIHave.Equals("ElectricCar"))
            {
                o_IsElectric = true;
            }

            return o_IsElectric;
        }

        private static bool checkIfTruckType(Person toCheck)
        {
            bool o_IsTruck = false;
            if (toCheck.WhatVehicleDoIHave.Equals("Truck") )
            {
                o_IsTruck = true;
            }

            return o_IsTruck;
        }
    }
}
