﻿using Ex03.GarageLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex03.ConsoleUI
{
    class CarsInGarageDetailes
    {
        private String m_OwnerName = "None";
        private String m_OwnerPhone = "None";
        private String m_VehicleState = "None";

        public CarsInGarageDetailes()
        {
            VehicleState = "UnderRepair";
        }

        public String OwnerName
        {
            set
            {
                m_OwnerName = value;
            }

            get
            {
                return m_OwnerName;
            }
        }

        public String OwnerPhone
        {
            set
            {
                if (int.TryParse(value, out int phoneNumberInt))
                {
                    if (phoneNumberInt > 0)
                    {
                        m_OwnerPhone = value;
                    }
                    else
                    {
                        throw new ValueOutOfRangeException("The number most be positive");
                    }
                }
                else
                {
                    throw new FormatException("You most enter numbers only");
                }
            }

            get
            {
                return m_OwnerPhone;
            }
        }

        public String VehicleState
        {
            set
            {
                if (value.Equals("UnderRepair") || value.Equals("Fixed") || value.Equals("PaidUp"))
                {
                    m_VehicleState = value;
                }
            }

            get
            {
                return m_VehicleState;
            }
        }
    }
}
