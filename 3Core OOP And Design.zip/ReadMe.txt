Please point to GarageLogic Dll from UI project for it will work as it need to.

in this project I work alot with Pholomorpizem,inheritance, InterFaces, UpCast&downCast 

some of the Cores of OOP.